package NJWproject.vocabularyListWeb.form;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class BookForm {
    String bookName;
    Long id;
}
