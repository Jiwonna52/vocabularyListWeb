package NJWproject.vocabularyListWeb.controller;


public class IndexController {
}
