package NJWproject.vocabularyListWeb.vocabulary;


public class VocabularyServiceTest {

}
